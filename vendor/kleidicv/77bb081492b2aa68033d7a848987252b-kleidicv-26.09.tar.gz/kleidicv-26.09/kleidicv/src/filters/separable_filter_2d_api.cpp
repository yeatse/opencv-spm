// SPDX-FileCopyrightText: 2023 - 2026 Arm Limited and/or its affiliates <open-source-office@arm.com>
//
// SPDX-License-Identifier: Apache-2.0

#include "kleidicv/dispatch.h"
#include "kleidicv/filters/separable_filter_2d.h"
#include "kleidicv/kleidicv.h"
#include "kleidicv/workspace/separable.h"

namespace kleidicv {

template <auto &StripeFunction, typename T>
kleidicv_error_t separable_filter_2d(const T *src, size_t src_stride, T *dst,
                                     size_t dst_stride, size_t width,
                                     size_t height, size_t channels,
                                     const T *kernel_x, size_t kernel_width,
                                     const T *kernel_y, size_t kernel_height,
                                     kleidicv_border_type_t border_type) {
  const auto validation = separable_filter_2d_validate(
      src, src_stride, dst, dst_stride, width, height, channels, kernel_x,
      kernel_width, kernel_y, kernel_height, border_type);
  if (validation.error != KLEIDICV_OK) {
    return validation.error;
  }

  return StripeFunction(src, src_stride, dst, dst_stride, width, height, 0,
                        height, channels, kernel_x, kernel_width, kernel_y,
                        kernel_height, validation.fixed_border_type);
}

}  // namespace kleidicv

#define KLEIDICV_DEFINE_C_API(name, type)                                      \
  KLEIDICV_MULTIVERSION_C_API_WITH_SME(                                        \
      name, &kleidicv::neon::separable_filter_2d_stripe<type>,                 \
      KLEIDICV_SVE2_IMPL_IF(kleidicv::sve2::separable_filter_2d_stripe<type>), \
      &kleidicv::sme::separable_filter_2d_stripe<type>, nullptr)

KLEIDICV_DEFINE_C_API(kleidicv_separable_filter_2d_stripe_u8, uint8_t);
KLEIDICV_DEFINE_C_API(kleidicv_separable_filter_2d_stripe_u16, uint16_t);

extern "C" {

kleidicv_error_t kleidicv_separable_filter_2d_u8(
    const uint8_t *src, size_t src_stride, uint8_t *dst, size_t dst_stride,
    size_t width, size_t height, size_t channels, const uint8_t *kernel_x,
    size_t kernel_width, const uint8_t *kernel_y, size_t kernel_height,
    kleidicv_border_type_t border_type) {
  return kleidicv::separable_filter_2d<kleidicv_separable_filter_2d_stripe_u8>(
      src, src_stride, dst, dst_stride, width, height, channels, kernel_x,
      kernel_width, kernel_y, kernel_height, border_type);
}

kleidicv_error_t kleidicv_separable_filter_2d_u8_sme(
    const uint8_t *src, size_t src_stride, uint8_t *dst, size_t dst_stride,
    size_t width, size_t height, size_t channels, const uint8_t *kernel_x,
    size_t kernel_width, const uint8_t *kernel_y, size_t kernel_height,
    kleidicv_border_type_t border_type) {
  return kleidicv::separable_filter_2d<
      kleidicv_separable_filter_2d_stripe_u8_sme>(
      src, src_stride, dst, dst_stride, width, height, channels, kernel_x,
      kernel_width, kernel_y, kernel_height, border_type);
}

kleidicv_error_t kleidicv_separable_filter_2d_u16(
    const uint16_t *src, size_t src_stride, uint16_t *dst, size_t dst_stride,
    size_t width, size_t height, size_t channels, const uint16_t *kernel_x,
    size_t kernel_width, const uint16_t *kernel_y, size_t kernel_height,
    kleidicv_border_type_t border_type) {
  return kleidicv::separable_filter_2d<kleidicv_separable_filter_2d_stripe_u16>(
      src, src_stride, dst, dst_stride, width, height, channels, kernel_x,
      kernel_width, kernel_y, kernel_height, border_type);
}

kleidicv_error_t kleidicv_separable_filter_2d_u16_sme(
    const uint16_t *src, size_t src_stride, uint16_t *dst, size_t dst_stride,
    size_t width, size_t height, size_t channels, const uint16_t *kernel_x,
    size_t kernel_width, const uint16_t *kernel_y, size_t kernel_height,
    kleidicv_border_type_t border_type) {
  return kleidicv::separable_filter_2d<
      kleidicv_separable_filter_2d_stripe_u16_sme>(
      src, src_stride, dst, dst_stride, width, height, channels, kernel_x,
      kernel_width, kernel_y, kernel_height, border_type);
}

}  // extern "C"
