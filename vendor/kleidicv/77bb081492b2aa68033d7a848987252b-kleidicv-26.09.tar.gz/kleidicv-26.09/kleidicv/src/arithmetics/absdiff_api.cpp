// SPDX-FileCopyrightText: 2023 - 2026 Arm Limited and/or its affiliates <open-source-office@arm.com>
//
// SPDX-License-Identifier: Apache-2.0

#include "kleidicv/arithmetics/absdiff.h"
#include "kleidicv/dispatch.h"
#include "kleidicv/kleidicv.h"

#define KLEIDICV_DEFINE_C_API(name, type)                               \
  KLEIDICV_MULTIVERSION_C_API_WITH_SME(                                 \
      name, &kleidicv::neon::saturating_absdiff<type>,                  \
      KLEIDICV_SVE2_IMPL_IF(&kleidicv::sve2::saturating_absdiff<type>), \
      &kleidicv::sme::saturating_absdiff<type>,                         \
      KLEIDICV_SME2_IMPL_IF(&kleidicv::sme2::saturating_absdiff<type>))

#define KLEIDICV_DEFINE_C_API_WITH_DEFAULT_SME2(name, type)             \
  KLEIDICV_MULTIVERSION_C_API_WITH_SME(                                 \
      name, &kleidicv::neon::saturating_absdiff<type>,                  \
      KLEIDICV_SVE2_IMPL_IF(&kleidicv::sve2::saturating_absdiff<type>), \
      &kleidicv::sme::saturating_absdiff<type>,                         \
      &kleidicv::sme2::saturating_absdiff<type>)

KLEIDICV_DEFINE_C_API(kleidicv_saturating_absdiff_u8, uint8_t);
KLEIDICV_DEFINE_C_API(kleidicv_saturating_absdiff_s8, int8_t);
KLEIDICV_DEFINE_C_API_WITH_DEFAULT_SME2(kleidicv_saturating_absdiff_u16,
                                        uint16_t);
KLEIDICV_DEFINE_C_API_WITH_DEFAULT_SME2(kleidicv_saturating_absdiff_s16,
                                        int16_t);
KLEIDICV_DEFINE_C_API(kleidicv_saturating_absdiff_s32, int32_t);
